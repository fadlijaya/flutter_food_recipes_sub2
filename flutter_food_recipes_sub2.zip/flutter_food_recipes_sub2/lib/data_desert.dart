class DataDesert {
  static List<String> name = [
    'Martabak Manis',
    'Gemblong',
    'Kue Ape',
    'Pukis Keju',
    'Pisang Goreng',
    'Kue Lapis',
    'Lapis Legit',
    'Kue Cucur',
    'Bika Ambon',
    'Klepon'
  ];

  static List<String> image = [
    'https://cdn.idntimes.com/content-images/post/20180910/09914fff0142d1498e8a72c64c03e98d.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/af1fc0865eb26da7b1aa427184a3b083.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/747ca0bfa7fb60b93344066ab1fb7773.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/11762a6fb0453e7f5958aae4d1c9ab4d.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/42d347b636c71d21e983e0cdb3309aa8.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/cf4c3b937ccc3fc534e3e58a1cbc6821.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/9c3ef0037c74b646dcf226a11eb28c87.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/368c60c77edf189f32da9813dedf3ff4.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/7a850a7610e91e63219e372d4df641d0.jpg',
    'https://cdn.idntimes.com/content-images/post/20180910/06e99a7a6ff13ecb6dea7ba7db6eb14e.jpg'
  ];

  static List<String> info = [
    'Meski banyak varian kekiniannya, martabak manis tetap termasuk makanan tradisional khas Indonesia. Adonan empuk dan legitnya itu lho yang bikin jatuh hati.',
    'Makanan yang terbuat dari adonan beras ketan putih ini namanya gemblong, tapi ada sebagian yang menyebutnya getas. Siraman gula merah yang bertemu dengan gurih adonan gemblong jadi pelengkap yang sempurna.',
    'Kue ape alias kue tetek ini jadi salah satu jajanan paling favorit di sejumlah kota, terutama Jakarta. Kamu bisa menemukannya di pasar tradisional atau pedagang kaki lima. Aroma pandannya yang wangi saat dibuat selalu bikin mereka yang lewat ngiler.',
    'Kue pukis sekilas rasanya mirip kue cubit, hanya saja ukurannya lebih besar dan adonannya padat.',
    'Pisang goreng selain jadi camilan atau pendamping minum teh, bisa juga disajikan di akhir sebagai hidangan penutup. Mantap!',
    'Kue lapis berbahan sagu ini bertekstur kenyal dan rasanya manis. Kamu tim langsung lahap atau yang makannya bertahap sambil melepas layer-nya satu-persatu nih?',
    'Beda banget sama kue lapis, lapis legit bisa dibilang cake tradisional. Seperti namanya, rasanya pun legit dan menyenangkan.',
    'Sore-sore makan kue cucur bareng secangkir teh hangat jadi hal sederhana yang bikin hati mendadak bahagia. Manisnya gula merah memang kawin banget jika dipadukan dengan adonan tepung dan santan yang gurih.',
    'Meski namanya bika Ambon, makanan satu ini justru berasal dari Medan, Sumatera Utara. Dinamai demikian konon katanya dijual pertama kali di Jalan Ambon, Medan.',
    'Kue bertekstur kenyal satu ini selalu punya "kejutan" dengan  ledakan gula merahnya yang lumer ketika digigit. Siapa yang masih suka kaget bahkan tersedak, nih?'
  ];
}