import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:flutter_food_recipes_sub2/detail_desert.dart';
import 'data_desert.dart';

class Desert extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return DesertState();
  }
}

class DesertState extends State<Desert> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Desert'),
      ),
      body: desertView(),
    );
  }
}

class desertView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    timeDilation = 5.0;

    return GridView.builder(
        itemCount: DataDesert.name.length,
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        padding: EdgeInsets.only(top: 10.0),
        itemBuilder: (BuildContext context, index) => Center(
              child: ListTile(
                  title: Column(
                    children: <Widget>[
                      Image.network(
                        DataDesert.image[index],
                        width: 400,
                        height: 150,
                        fit: BoxFit.cover,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        DataDesert.name[index],
                        style: TextStyle(color: Colors.blueGrey),
                      )
                    ],
                  ),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute<void>(
                        builder: (BuildContext context) {
                      return Scaffold(
                        body: Container(
                          child: DetailDesert(
                            image: DataDesert.image[index],
                            name: DataDesert.name[index],
                            info: DataDesert.info[index],
                          ),
                        ),
                      );
                    }));
                  }),
            ));
  }
}
