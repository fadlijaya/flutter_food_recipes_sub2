import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'data_breakfast.dart';
import 'detail_breakfast.dart';

class Breakfast extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return BreakfastState();
  }
}

class BreakfastState extends State<Breakfast> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Breakfast'),
      ),
      body: breakfastView(),
    );
  }
}

class breakfastView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    timeDilation = 5.0;

    return GridView.builder(
        itemCount: DataBreakfast.name.length,
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        padding: EdgeInsets.only(top: 10.0),
        itemBuilder: (BuildContext context, index) => Center(
                child: ListTile(
              title: Column(
                children: <Widget>[
                  Image.network(
                    DataBreakfast.image[index],
                    width: 400,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    DataBreakfast.name[index],
                    style: TextStyle(color: Colors.blueGrey),
                  )
                ],
              ),
              onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (BuildContext context) {
                  return Scaffold(
                    body: Container(
                      child: DetailBreakfast(
                        image: DataBreakfast.image[index],
                        name: DataBreakfast.name[index],
                        info: DataBreakfast.info[index],
                      ),
                    ),
                  );
                }));
              },
            )));
  }
}
